####
## Benjamin Bois 17/01/2016
## Mise � jour
## le 9/10/2017 - B. Bois
## le 30/9/2020 - B. Bois :
#       - Chargement simultan� de plusieurs rasters avec la fonction stack()
#       - Calcul d'une moyenne de plusieurs raster avec la fonction calc()
#       - Int�gration de l'�quation (4) de l'article de Strauss et al. (1997) pour estimer le facteur d'�rosivit� R
####

### chemin du dossier de travail ###
setwd('../Data/')

### chargement des paquets R pour lecture de donnees shapefiles et images
library(sp) # Package avec les options de base pour faire de l'analyse g�ographique (R = SIG)
library(rgdal) # Package permettant d'int�grer les outils GDAL (Geospatial Data Abstraction Library - www.gdal.org)
library(raster) # Un package tres simple d'utilisation pour gerer les raster

# Lire plusieurs rasters en m�me temps
# identifier les  raster � lire
list.files(path = "InterpolRegKrig/")
# On se met dans le r�pertoire de travail dans lequel 
# se trouvent tous les rasters (.tif)
# obtenus par regression-krieage
setwd("E:/Benjamin/_Enseignement/2022-2023/M2SEME/UE2-TraitDonnees/TP4 - BenjaminBois/Data/InterpolRegKrig/")
# On cr�� un vecteur qui contient les noms de tous les fichiers (raster .tif) � traiter 
# Exemple ci-dessous, des ann�e 1961 � 1970
noms.rasters.a.lire <- paste0("y",1961:1970,".tif")
# On charge en m�moire tous ces rasters dans un objet "raster" multibande, appel� "stack" dans R
st <- stack(noms.rasters.a.lire)
# Que contient notre stack?
st
#Tracer tous les rasters contenus dans le stack
plot(st)

# On calcule la moyenne des valeurs des rasters � chaque pixel
Precip.moy <- calc(st, mean)

# CALCUL DU COEFFICENT D'EROSIVITE R : ----
# QUEL COEFFICIENT R CALCULER? 
# Selon Renard et Freimund (1994 - Revue Journal of Hydrology - equation 11 page 299)
# R, exprim� en MJ mm ha-1 h-1, se calcule ainsi
#  � partir des pr�cipitations annuelles (en mm) : 
Rfact <- 0.04830*Precip.moy^1.610
plot(Rfact)
# mais cette �quation a �t� calibr�e pour les conditions climatiques des USA

# On a une meilleure approche probablement du R dans le nord-est
# de la France avec l'�quation de Strauss et al. (1997 - revue Archives of Agronomy and Soil Science) 
# (equation 4 , page 125) :
Rfact <- -7.31+0.104*Precip.moy
# ATTENTION, les unit�s de Rfact ne sont pas les m�me
# Pour calculer Rfact en MJ mm ha-1 h-1 il faut multiplier par 10 : 
Rfact <- -7.31+0.104*Precip.moy * 10

# Il ne reste plus qu'a sauvegarder le raster (fonction writeRaster) pour
# �ventuellement l'afficher dans QGIS


