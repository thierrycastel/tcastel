####
## Benjamin Bois 17/01/2016
####

### chemin du dossier de travail ###
setwd("E:/Benjamin/_Enseignement/2022-2023/M2SEME/UE2-TraitDonnees/TP5 - BenjaminBois - Evaluation/Data")

### chargement des paquets R pour lecture de donnees shapefiles et images
library(maptools) ## ou require(maptools)
library(rgdal)
library(sp)
library(raster) # Un package tres simple d'utilisation pour gerer les raster
library(geoR)
source("../FonctionsR/zmap.plot.R")

## Carte des départements Bourguignons
limDptL93 <- readShapePoly("bourgogne_dpt_L93.shp", proj4string=CRS("+init=epsg:2154"))

## Lecture de la couche vectorielle délimitant le bassin versant de la Sorme
BVSorme <- readShapePoly("BVSorme.shp", proj4string=CRS("+init=epsg:2154"))

## Lecture du MNT à 5m
mnt5m <- raster("mnt.tif")
proj4string(mnt5m)

# L'interpolation des données à 5m prendrait trop de temps...et puis
# vouloir avoir des cumul de pluie tous les 5 mètres...ce n'est pas très utile
# Alors pour faciliter les calculs, on prend le MNT de l'IGN à résolution 75m 
# (environ un demi hectare ou 0.0056 km²)
mnt75m <- raster("BDALTIV2_75M_FXX_0750_6675_MNT_LAMB93_IGN69.asc")
proj4string(mnt75m) # Pas de de système de coordonnées détécté  ici...il faut le renseigner
proj4string(mnt75m) <- CRS("+init=epsg:2154")
# Pour limiter les temps de calcul, on découpe le MNT sur la zone du Bassin versant (cf fin exercice précédent)
mnt75mBV <- crop(mnt75m, BVSorme) 

### Lecture des donnees annuelles de précipitation ----
pAn <- read.csv("PrecipAn_MF.csv")

### Nous allons etudier ici créer une boucle pour traiter toutes les années d'un coup
# On crée un object --> ce sera un tableau  permettrant d'inscrire les stats automatiquement
stats.interpol <- c()
v <- "y1961"
col.annees <- colnames(pAn)[-1:-4]
  for(v in col.annees) # On change à chaque boucle le nom du mois à traiter
  {
    dat <- pAn[, c("NumPoste","X","Y", "Alti",v)]
    dat <- na.omit(dat)
    coords <- dat[,c("X","Y")]
    
    ### Interpolation par regression linéaire  ----
    pts.source <- data.frame(v = dat[,v], Alti = dat[,"Alti"], X =  coords[,"X"], Y =  coords[,"Y"]) # Isolement des données de l'année à traiter
    mod <- lm(v ~ Alti + X + Y, data= pts.source) # Modèle de regression linéaire multiple

      # Statistiques    ----
    lm.biais <- mean(mod$residuals) # Biais
    lm.sd <- sd(mod$residuals) # ecart-type de résidus
    lm.rmse <- sqrt(mean( mod$residuals^2)) #RMSE
    lm.adj.r2 <- summary(mod)$adj.r.squared
    
    
    ### Interpolation spatiale par  regression linaire ----
    pts.cibles <- data.frame(Alti = getValues(mnt75mBV), X=coordinates(mnt75mBV)[,1],  Y=  coordinates(mnt75mBV)[,2])
    
    pred.val <- predict.lm(mod, newdata = pts.cibles)
    
    # Nouveau raster à qui on attribue les données spatialisées de la variable  :
    pred.raster <- mnt75mBV
    pred.raster[] <- NA ### On efface toutes les données du raster
    
    pred.raster[] <- pred.val ### On affecte les données interpolées de la variable au raster

    ### Sauvegarde du raster de l'interpolation basée sur la regression linéaire seule----
    nom.raster <- paste0("./InterpolRegLin/",v,".tif")
    dir.create("./InterpolRegLin/", showWarnings = F)
    writeRaster(pred.raster, filename = nom.raster, format="GTiff", overwrite=T)
    
    ### INTERPOLATION DES RESIDUS PAR KRIGEAGE ORDINAIRE : -----
    # Attribution des résidus du modèle à la 
    # "couche vectorielle" (SpatialPointsDataFrame) dat
    # dat <- predict(mod) - dat[,v]
    
    ### Variogramme ----
    vg <- variog(coords = coords, data = mod$residuals)

      # Pour paramétrer le modele automatiquement, on fixe des valeurs de initiales
    monmodele <- "spherical"
    pepite <- 0 
    portee <- mean(vg$u) # La distance moyenne sur l'ensemble du variogramme
    palier <- mean(vg$v)-pepite # La valeur moyenne de semivariance calculée.
    
    vgfit <- variofit(vario = vg, cov.model = monmodele, nugget = pepite, ini.cov.pars = c(palier, portee), max.dist = 100000)
    
    # Ici on va créer un graph au format png (un cousin du jpeg) du variogramme des résidus de chaque variable interpolée
    dir.create("./variogrammes", showWarnings = F) # Creation d'un repertoire
    png(paste0("./variogrammes/variogramme_",v,".png"),height = 480, width = 480,pointsize=18)
      plot(vg)
      text(vg$u, vg$v, labels=vg$n, pos=1, cex=0.8)
      lines(vgfit)
      title(main = v)
    dev.off()
    
    ### Krigeage ----
    # Raster cible 
    # Nouveau raster à qui on attribue les résidus spatialisés  :
      res.raster <- mnt75mBV
    res.raster[] <- NA ### On efface toutes les données du raster
    # Krigeage : 
    # il faut d'abord indiquer avec "krige.control" les paramètres du krigeage
    kg.cont <- krige.control(type.krige = "ok", obj.model = vgfit)
    # Et ensuite, on prédit la données, aux points "cible" appelés "locations"
    kg <- krige.conv(coords=coords, data = mod$residuals, krige=kg.cont, locations=coordinates(res.raster))
    
    # Attribution des résidus krigés au raster
    res.raster[] <- kg$predict


    ### On peut enfin ajouter les résidus spatialisés par krigeage
    ### a la variable spatialisée par regression multiple 
    ### --> c'est le regression-krigeage
    rk.raster <- pred.raster - res.raster
    
    
    ### Enregistrement du raster produit au format ESRI ASCII GRID ----
    ## Donner un nom au raster de sortie
    nom.raster <- paste0("./InterpolRegKrig/",v,".tif")
    dir.create("./InterpolRegKrig/", showWarnings = F)
    writeRaster(rk.raster, filename = nom.raster, format="GTiff", overwrite=T)
    
    
    # Validation croisée
    pred.valid <- c() # ici on créé un vecteur qui va emagasiner les données de validation croisée
    for(i in 1:nrow(dat))
    {
      sdat <- pts.source[-i,] #On retire une station
      cv.mod <- lm(v ~ Alti + X + Y, data= sdat) 
      # Estimation du  cumul annuel de précipitation à la station que l'on a éliminé
      pred.lm.valid <- predict.lm(cv.mod, newdata = data.frame(X=pts.source$X[i], Y=pts.source$Y[i], Alti=pts.source$Alti[i]))
      cv.res <-cv.mod$fitted.values - sdat[,"v"]
      
      monmodele <- "spherical"
      vg <- variog(coords = sdat[,c("X","Y")], data = cv.res)
      pepite <- 0 
      portee <- mean(vg$u) # La distance moyenne sur l'ensemble du variogramme
      palier <- mean(vg$v)-pepite # La valeur moyenne de semivariance calculée.
      vgfit <- variofit(vario = vg, cov.model = monmodele, nugget = pepite, ini.cov.pars = c(palier-pepite, portee), max.dist=100000)
      kg.cont <- krige.control(type.krige = "ok", obj.model = vgfit)
      # on prédit la donnée, aux points "cible" appelés "locations", ici --> la station que l'on a retirée!
      kg <- krige.conv(coords=sdat[,c("X","Y")], data = cv.res, krige=kg.cont, locations=data.frame(X=pts.source$X[i], Y=pts.source$Y[i]))
      
      pred.valid <- c(pred.valid, pred.lm.valid - kg$predict)
    }
    
    cv.r2 <- cor(pred.valid, pts.source$v, use="pairwise.complete.obs")^2
    valid.residus <- pts.source$v - pred.valid
    cv.rmse <- sqrt(mean(valid.residus^2)) # RMSE
    
    
    ### Ajout des stats au tableau de synthese
    stats.interpol <- rbind(stats.interpol, c(Variable = v, BiaisModLineaire = lm.biais, R2lModLineaire = lm.adj.r2, RMSEModLineaire = lm.rmse, R2.ValidRegressionKrigeage = cv.r2, RMSE.ValidRegressionKrigeage = cv.rmse))
  }

