####
## Benjamin Bois 17/01/2016
## Mis à jour le 9/10/2017 - B. Bois
####
 
#### TOUT EFFACER DANS R ----
rm(list=ls())
gc()
# effacer les graphs
dev.off()
 
### chemin du dossier de travail ###
setwd('../Data/')
#setwd('E:/Benjamin/_Enseignement/2020-2021/M2SEME/UE2-TraitDonnees/TP3 - BenjaminBois/Data/')

### chargement des paquets R pour lecture de donnees shapefiles et images
library(sp) # Package avec les options de base pour faire de l'analyse géographique (R = SIG)
library(maptools) ## ou require(maptools) - permet de lire des fichiers au format Shape facilement
library(rgdal) # Package permettant d'intégrer les outils GDAL (Geospatial Data Abstraction Library - www.gdal.org)
library(raster) # Un package tres simple d'utilisation pour gerer les raster
library(geoR)  # Package de géostatistiques
#library(gstat)
source("../FonctionsR/zmap.plot.R")

## Carte des départements Bourguignons
limDptL93 <- readOGR("bourgogne_dpt_L93.shp")

## Lecture de la couche vectorielle délimitant le bassin versant de la Sorme
BVSorme <- readOGR("BVSorme.shp")

## Lecture du MNT à 5m
mnt5m <- raster("mnt.tif")
proj4string(mnt5m)
# Variante  : mnt5m <- readGDAL("mnt.tif")

# L'interpolation des données à 5m prendrait trop de temps...et puis
# vouloir avoir des cumul de pluie tous les 5 mètres...ce n'est pas très utile
# Alors pour faciliter les calculs, on prend le MNT de l'IGN à résolution 75m 
# (environ un demi hectare ou 0.0056 km²)
mnt75m <- raster("BDALTIV2_75M_FXX_0750_6675_MNT_LAMB93_IGN69.asc")
proj4string(mnt75m) # Pas de de système de coordonnées détécté  ici...il faut le renseigner
proj4string(mnt75m) <- CRS("+init=epsg:2154")

### Lecture des donnees annuelles de précipitation ----
pAn <- read.csv("PrecipAn_MF.csv")
View(pAn)


#### Nous allons etudier ici une seule variable : les précipitations de l'année 2001
# On identifie la variable à analyser (colonne nommée "2001")
v <- "y2001"
# On isole les coordonnées et l'année 2001
dat <- pAn[, c("NumPoste","X","Y", "Alti",v)]
dim(dat) # On a 87 stations
summary(dat) # Pour 5 stations, pas de cumul en 2000 (du fait de données manquantes)
# et on élimine les données manquantes
dat <- na.omit(dat)
summary(dat)
dim(dat) # Reste donc 82 stations


### INterpolation par regression linéaire  ----
mod <- lm(formula(paste0(v," ~ Alti + X + Y")), data= dat)
mod
summary(mod)

# Statistiques du modèle linéaire : 

# Nuage de points entre valeurs observées et prédites
lims <- range(dat[,v], mod$fitted.values,na.rm=T)
plot(dat[,v], mod$fitted.values, xlab="Valeurs observées [mm]", ylab="Valeurs prédites [mm]", xlim=lims, ylim=lims, pch=20, col=rgb(0,0,0,alpha=0.3))
abline(a=0,b=1)

# Les résidus...il s'agit de la différence entre valeur observées et valeurs prédites par le modèle
residus <- predict(mod) - dat[,v]

mean(residus) # Biais : si positif, alors le modèle sous-estime (car les valeurs mesurées sont plus élevées que celles prédites par le modèle)
hist(residus) # Les résidus suivent-t-ils une loi normale?
summary( residus)
sd(residus) # ecart-type de résidus
sqrt(mean(residus^2)) #RMSE

### Interpolation spatiale par  regression linaire ----
### On estime la valeur de la variable pour chaque cellule (pixel)
### du MNT à 75 m
### Les coordonnées des points cibles sont donc le centre de chaque pixel

# Pour limiter les temps de calcul, on découpe le MNT sur la zone du Bassin versant (cf fin exercice précédent)
mnt75mBV <- crop(mnt75m, BVSorme) 

### Afin d'appliquer le modèle linéaire aux points cibles, il faut créer un data.frame avec les mêmes noms de variables que ceux présents dans le modèle (cf. data.frame appelé "pts.source" plus haut)
pts.cibles <- data.frame(Alti = getValues(mnt75mBV), X=coordinates(mnt75mBV)[,1],  Y=  coordinates(mnt75mBV)[,2])
head(pts.cibles) # Coordonnées des pixels du mnt75m
dim(pts.cibles) # Restent 18048 pixels 

### L'interpolation est réalisée en prédisant le modèle au point cibles
#pred.val <- predict.lm(mod, newdata = pts.cibles)
pred.val <- coef(mod)["(Intercept)"] +
  coef(mod)["Alti"] * pts.cibles$Alti +
  coef(mod)["X"] * pts.cibles$X +
  coef(mod)["Y"] * pts.cibles$Y

# Nouveau raster à qui on attribue les données spatialisées de la variable  :
pred.raster <- mnt75mBV
pred.raster[] <- NA ### On efface toutes les données du raster

pred.raster[] <- pred.val ### On affecte les données interpolées de la variable au raster

# Carte du raster produit
vCols <- colorRampPalette(colors=c("red", "wheat","blue")) # Palette de couleur pour la pluie
plot(pred.raster, col=vCols(50))
plot(limDptL93, add=T)
plot(BVSorme, add=T)


### INTERPOLATION DES RESIDUS PAR KRIGEAGE ORDINAIRE : -----
# Attribution des résidus du modèle de regression dans le tableau de données 
dat$residus <- residus

## Carte des résidus
# En bleu : valeurs sous-estimées (mesures supérieurs à celles du modèle) ; en rouge : valeurs sur-estimées
  # Ensemble des stations
zmap.plot(x = dat$X, y = dat$Y, z = residus, x.leg = "bottomright", col="black", bg=vCols, cex.leg=0.8) 
plot(BVSorme, add=T)

# Zoom sur le bassin versant de la sorme
plot(mnt75m, col=grey.colors(50))
plot(BVSorme, add=T)
zmap.plot(x = dat$X, y = dat$Y, z = residus, add=T,x.leg = "bottomright", col="black", bg=vCols, cex.leg=0.4)

### Variogramme ----
library(geoR)
vg <- variog(coords = dat[,c("X","Y")], data = residus, max.dist = 110000)

str(vg)
plot(vg, type="o")
  # Affiche le nombre de couple de points utiliser pour calculer la semi-variance (il en faut au minimum 30, de préférence)
text(vg$u, vg$v, labels=vg$n, pos=1)

monmodele <- "spherical"
pepite <- 2000
portee <- 50000
palier <- 25000 - pepite
vgfit <- variofit(vario = vg, cov.model = monmodele, nugget = pepite, ini.cov.pars = c(palier, portee))

plot(vg, type="b")
text(vg$u, vg$v, labels=vg$n, pos=3, cex=0.8)
lines(vgfit)
  # Le modèle ne colle pas très bien au variogramme. Le plus important, c'est que le variogramme soit bien ajusté sur les distances les plus courtes : les points les plus proches de la zone à interpolée vont jouer un rôle majeur
  # Deux options
# 1 : on fixe les paramètres du modèle 
vgfit <- variofit(vario = vg, cov.model = monmodele, nugget = pepite, ini.cov.pars = c(palier, portee))
#################################################
vgfit$cov.pars <- c(palier, portee) # On modifie le modèle en choisissant les valeurs de palier et de portée
vgfit$nugget <- pepite # idem pour l'effet pepite
#################################################
plot(vg, type="b")
text(vg$u, vg$v, labels=vg$n, pos=3, cex=0.8)
lines(vgfit, col="red")

# AVEC LE PACKAGE GSTAT
library(gstat)
sdat <- dat
coordinates(sdat) <- ~X+Y
vg2 <- variogram(formula(paste0(v,"~1")), data=sdat, cutoff=80000, )
plot(vg2)
plot(vg2$dist, vg2$gamma, type="o")
text(vg2$dist, vg2$gamma, labels=vg2$np, pos=1)

# # Possibilité aussi d'ajuster à l'oeil
# vgfit <- eyefit(vg) # --> UNE NOUVELLE BOITE DE DIALOGUE S'OUVRE
# plot(vg, type="b")
# text(vg$u, vg$v, labels=vg$n, pos=3, cex=0.8)
# lines(vgfit)
# 
# # 2 : on diminue la distance d'ajustement automatique du modèle de variogramme. Ici, la distance de 100 km (100 000 m) semble raisonnable...après...le variogramme décroit
vgfit <- variofit(vario = vg, cov.model = monmodele, nugget = pepite, ini.cov.pars = c(palier, portee),max.dist = 50000)
plot(vg, type="b")
text(vg$u, vg$v, labels=vg$n, pos=3, cex=0.8)
lines(vgfit)


### Krigeage des résidus ----
# Raster cible 
# Nouveau raster à qui on attribue les résidus spatialisés  :
res.raster <- mnt75mBV
res.raster[] <- NA ### On efface toutes les données du raster
# Krigeage : 
# il faut d'abord indiquer avec "krige.control" les paramètres du krigeage
kg.cont <- krige.control(type.krige = "ok", obj.model = vgfit)
# Et ensuite, on prédit la donnée, aux points "cibles" appelés "locations"
kg <- krige.conv(coords=dat[,c("X","Y")], data = residus, krige=kg.cont, locations=coordinates(res.raster))

# Attribution des résidus krigés au raster
res.raster[] <- kg$predict
plot(res.raster)
plot(BVSorme, add=T)
plot(pred.raster)

zmap.plot(x=dat$X, y=dat$Y, z=residus, cex.leg=0.6)
rCols <- colorRampPalette(c("blue","wheat","red"))
plot(res.raster, add=T, col=rCols(50))

### On peut enfin ajouter les résidus spatialisés par krigeage, 
### pour corriger l'erreur du modèle de regesssion linéaire multiple
### --> c'est l'étape finale du regression-krigeage
rk.raster <- pred.raster - res.raster

plot(rk.raster, col=vCols(50))
plot(BVSorme, add=T)


### Enregistrement du raster produit au format GeoTiff ----
rk.raster <- crop(rk.raster, BVSorme)
rk.raster <- mask(rk.raster, BVSorme)
plot(rk.raster)
rk.raster

## Donner un nom au raster de sortie
dir.create("InterpolRegKrig")
nom.raster <- paste0("./InterpolRegKrig/RegKrig_CumulPrec_",v,".tif")
# On enregistre le fichier
writeRaster(rk.raster, filename = nom.raster, format="GTiff", overwrite=T)


### Validation croisée ----
# Une boucle
for(i in 1:10)
{
  print(paste0("tour n°",i))
}

## Cela permet d'estimer la qualité du krigeage
# Principe : on élimine tour à tour une station et on interpole les données à la station éliminée
i <- 1 # pour tester la boucle
# Boucle de traitement
pred.valid <- c() # ici on créé un vecteur qui va emagasiner les données de validation croisée
for(i in 1:nrow(dat))
{
  sdat <- dat[-i,] #On retire une station
  cv.mod <- lm(formula(paste0(v," ~ Alti + X + Y")), data= sdat) 
  # Estimation du  cumul annuel de précipitation à la station que l'on a éliminé
  pred.lm.valid <- predict.lm(cv.mod, newdata = data.frame(X=dat$X[i], Y=dat$Y[i], Alti=dat$Alti[i]))
  #cv.res <- pred.lm.valid - sdat[,v]
  cv.res <- cv.mod$fitted.values - sdat[,v]
  
    
  monmodele <- "spherical"
  vg <- variog(coords = sdat[,c("X","Y")], data = cv.res)
  pepite <- 0 
  portee <- mean(vg$u) # La distance moyenne sur l'ensemble du variogramme
  palier <- mean(vg$v)-pepite # La valeur moyenne de semivariance calculée.
  vgfit <- variofit(vario = vg, cov.model = monmodele, nugget = pepite, ini.cov.pars = c(palier, portee), max.dist=80000)
  kg.cont <- krige.control(type.krige = "ok", obj.model = vgfit)
  # on prédit la donnée, aux points "cible" appelés "locations", ici --> la station que l'on a retirée!
  kg <- krige.conv(coords=sdat[,c("X","Y")], data = cv.res, krige=kg.cont, locations=data.frame(X=dat$X[i], Y=dat$Y[i]))
  
  pred.valid <- c(pred.valid, pred.lm.valid - kg$predict)
}

# Etude des résulats de la validation croisée -----
  lims <- range(c(dat[,v],pred.valid, mod$fitted.values)) # valeurs extrêmes des données obs. et prédites
  # Prédictions réalisées uniquement par regression multiple (ronds orange)
plot(x=dat[,v], y=mod$fitted.values, xlim=lims,ylim=lims, xlab="Cumul de prec. observé [mm]", ylab="Cumul de prec. estimé  (Validation croisée) [mm]", pch=20, col="orange")
  # Prédictions réalisées par regression multiple puis krigeage des résidus (aka Regression-Krigeage), (triangles vert foncés transparents)
points(x=dat[,v], y=pred.valid, xlim=lims,ylim=lims, col=rgb(red = 0,green = 0.3,blue = 0,alpha = 0.5),pch=17)
abline(a=0,b=1)

# QU'EN PENSEZ VOUS?

# Résidus (="erreurs") de la validation
valid.residus <- pred.valid - dat[,v]
# Quelques statistiques permettant d'évaluer la précision (ou l'imprécision) de l'interpolation
sd(valid.residus) # Ecart-type des résidus
sqrt(mean(valid.residus^2)) # RMSE
cor(dat[,v],pred.valid, use="pairwise.complete.obs")^2 # coefficient de determination

# Comparaison des performances de la  regression seule et du regression-krigeage
  # Coeff de determination
    # Regression linéaire
summary(mod)$adj.r.squared
    # Regression krigeage
cor(dat[,v],pred.valid, use="pairwise.complete.obs")^2 # coefficient de determination
    
  # "Erreur moyenne" d'interpolation (RMSE, pour Root Mean Squared Error)
    # Regression linéaire
sqrt(mean( mod$residuals^2)) #RMSE
    # Regression krigeage
sqrt(mean( valid.residus^2)) #RMSE


# Carte des résidus du Regression-Krigeage
# Ensemble des stations
zmap.plot(x = dat$X, y = dat$Y, z = valid.residus, x.leg = "bottomright", col="black", bg=vCols, n = 10, ncol.leg = 2) 
plot(BVSorme, add=T)

# Zoom sur le bassin versant de la sorme
plot(mnt75m, col=grey.colors(50))
plot(BVSorme, add=T)
zmap.plot(x = dat$X, y = dat$Y, z = valid.residus, x.leg = "topright", col="black", bg=vCols, n = 10, ncol.leg = 3, add=T) 


# CONCLUSIONS SUR LA PRECISION DE L'INTERPOLATION DE LA PLUIE AU NIVEAU DU BASSIN VERSANT DE LA SORME?

### BONUS : et pourquoi ne pas directement faire du krigeage, sans intégrer le relief, la latitude et la longitude
# ....bref....sans regression linéaire préalable!
# C'est le KRIGEAGE ORDINAIRE ------------
  ### Etude du variogramme des pluies annuelles ----
vg <- variog(coords = dat[,c("X","Y")], data = dat[,v])

str(vg)
plot(vg)
# Affiche le nombre de couple de points utiliser pour calculer la semi-variance (il en faut au minimum 30, de préférence)
text(vg$u, vg$v, labels=vg$n, pos=1)

monmodele <- "spherical"
pepite <- 2000
portee <- 50000
palier <- 25000 - pepite
vgfit <- variofit(vario = vg, cov.model = monmodele, nugget = pepite, ini.cov.pars = c(palier-pepite, portee),max.dist = 100000)
plot(vg, type="b")
text(vg$u, vg$v, labels=vg$n, pos=3, cex=0.8)
lines(vgfit)

### Krigeage des cumuls de précipitation ----
# Raster cible 
# Nouveau raster à qui on attribue les résidus spatialisés  :
ko.raster <- mnt75mBV
ko.raster[] <- NA ### On efface toutes les données du raster
# Krigeage : 
# il faut d'abord indiquer avec "krige.control" les paramètres du krigeage
kg.cont <- krige.control(type.krige = "ok", obj.model = vgfit)
# Et ensuite, on prédit la donnée, aux points "cibles" appelés "locations"
kg <- krige.conv(coords=dat[,c("X","Y")], data = dat[,v], krige=kg.cont, locations=coordinates(res.raster))

# Attribution des résidus krigés au raster
ko.raster[] <- kg$predict
plot(ko.raster)
plot(BVSorme, add=T)

# Validation croisée du krigeage ordinaire
    # Ici, pas de résidus à kriger...on a une fonction toute prête pour la validation croisée
cv.ko <- xvalid(coords=dat[,c("X","Y")], data = dat[,v], model=vgfit)

  # Comparaison des trois méthodes d'interpolation de la pluie -----
  # -->  krigeage ordinaire, regression multiple et regression krigeage ----
# Nuages de points
lims <- range(c(dat[,v],pred.valid, mod$fitted.values, cv.ko$predicted)) # valeurs extrêmes des données obs. et prédites
# Prédictions réalisées uniquement par regression multiple (ronds orange)
plot(x=dat[,v], y=mod$fitted.values, xlim=lims,ylim=lims, xlab="Cumul de prec. observé [mm]", ylab="Cumul de prec. estimé  (Validation croisée) [mm]", pch=20, col="orange")
# Prédictions réalisées par regression multiple puis krigeage des résidus (aka Regression-Krigeage), (triangles vert foncés transparents)
points(x=dat[,v], y=pred.valid, xlim=lims,ylim=lims, col=rgb(red = 0,green = 0.3,blue = 0,alpha = 0.5),pch=17)
abline(a=0,b=1)
# Prédictions réalisées uniquement par krigeage ordinaire (carrés)
points(x=dat[,v], y=cv.ko$predicted,  pch=0)

# Coeff de determination
  # Krigeage ordinaire
  cor(cv.ko$data, cv.ko$predicted, use="pairwise.complete.obs")^2
  # Regression linéaire
  summary(mod)$adj.r.squared^2
  # Regression krigeage
  cor(dat[,v],pred.valid, use="pairwise.complete.obs")^2 # coefficient de determination

# "Erreur moyenne" d'interpolation (RMSE, pour Root Mean Squared Error)
  # Krigeage ordinaire
  sqrt(mean( cv.ko$error^2)) 
  # Regression linéaire
  sqrt(mean( mod$residuals^2)) 
  # Regression krigeage
  sqrt(mean( valid.residus^2)) 

  # CONCLUSIONS ?
