####
## Benjamin Bois 17/01/2016
## Mis à jour le 9/10/2017 - B. Bois
## Mis à jour le 3/10/2019 - B. Bois
## Révisé le 22/09/2023 - T. Castel
####

### chemin du dossier de travail ### ----
# setwd("E:/Benjamin/_Enseignement/2022-2023/M2SEME/UE2-TraitDonnees/TP3 - BenjaminBois/Data/")

setwd("../Data")

### chargement des paquets R pour lecture de donnees shapefiles et images
library(sp) # Package avec les options de base pour faire de l'analyse géographique (R = SIG)
library(sf) ## ou require(maptools) - permet de lire des fichiers au format Shape facilement
## library(rgeos)
## library(rgdal) # Package permettant d'intégrer les outils GDAL (Geospatial Data Abstraction Library - www.gdal.org)
library(raster) # Un package tres simple d'utilisation pour gerer les rasters
library(ggplot2)


limDptL93 <- st_read("bourgogne_dpt_L93.shp")
# proj4string((limDptL93))
# str(limDptL93)
## Lecture de la couche vectorielle délimitant le bassin versant de la Sorme
BVSorme <- st_read("BVSorme.shp")

ggplot() +
  geom_sf(data = limDptL93["NOM_DEPT"], color = "black", fill = NA) +
  geom_sf(data = BVSorme, color = "black", fill = NA)

## Lecture du MNT à 5m
mnt5m <- raster("mnt.tif")
mnt <- as.data.frame(mnt5m)

class(mnt)
str(mnt)

proj4string(mnt5m)
# Graph du relief
plot(mnt5m)
contour(mnt5m, add = T, nlevels = 30)
plot(mnt5m, col = terrain.colors(256))
contour(mnt5m, add = T)


# L'interpolation des données à 5m prendrait trop de temps...et puis
# vouloir avoir des cumuls de pluie tous les 5 mètres...ce n'est pas très utile
# Alors pour faciliter les calculs, on prend le MNT de l'IGN à résolution 75m
# (environ un demi hectare ou 0.0056 km²)
mnt75m <- raster("BDALTIV2_75M_FXX_0750_6675_MNT_LAMB93_IGN69.asc")
proj4string(mnt75m) # Pas de de système de coordonnées détécté  ici...il faut le renseigner
proj4string(mnt75m) <- CRS("+init=epsg:2154")
plot(mnt75m)
mnt75mdf <- as.data.frame(mnt75m, xy = TRUE)
colnames(mnt75mdf) <- c("x", "y", "alti")

ggplot(data = mnt75mdf) +
  geom_raster(aes(x = x, y = y, fill = `alti`)) +
  geom_sf(data = limDptL93["NOM_DEPT"], color = "black", fill = NA) +
  geom_sf(data = BVSorme, color = "black", fill = NA)


### Préparation des données ----
### Lecture des coordonnées des données climatiques
coords <- read.csv(file = "MFpostesRR.csv", sep = ",", dec = ".")
head(coords)
# Ici coordonnées latitutde / longitude (sphériques) ou Lambert 2 étendu.
# Il faut donc reprojeter tout cela en Lambert 93
# Vous pouvez le faire avec QGIS
# en important le fichier texte et sauvegardant
# en shapefile (sous système de coordonnées lambert 93)
# Dans ce cas, lisez le shapefile "points" représentant les stations avec la fonction
# readShapePoints("nomfichierpoint.shp" , proj4string=CRS("+init=epsg:2154"))
                                        # Sinon cela peut se faire avec R

stations <- coords # on copie le tableau coord
class(coords)
coordinates(stations) <- ~ LonLB2 + LatLB2 # Cette fonction transforme le tableau stations en couche géographique "points"
proj4string(stations) <- CRS("+init=epsg:27572")
stations <- spTransform(stations, CRS("+init=epsg:2154"))
# R (package sp) appelle cela des SpatialPointsDataFrame
class(stations)
## transforme l'objet sp en objet sf 
stationsdf <- as.data.frame(stations)
stationssf <- st_as_sf(x = stationsdf, coords = c("coords.x1", "coords.x2"),
                       crs = "+init=epsg:2154")

## trace les stations, les limites des départements et les limites
## du BV de la Sorme

ggplot() +
  geom_sf(data = stationssf, color = "black", fill = NA) +
  geom_sf(data = limDptL93["NOM_DEPT"], color = "black", fill = NA) +
  geom_sf(data = BVSorme, color = "black", fill = NA)


ggplot(data = mnt75mdf) +
  geom_raster(aes(x = x, y = y, fill = `alti`)) +
  scale_fill_viridis_c() +
  geom_sf(data = stationssf, color = "black", fill = NA) +
  geom_sf(data = BVSorme, color = "red", fill = NA)

dim(stations) # Dimension de la table des attributs
# Et si on regardait la table des attributs justement
View(stations@data)
coordinates(stations)


# On a les coordonnées des stations...il nous fait maintenant analyser les précipitations!
prec <- read.csv("MFdataRRSorme.csv")
# Variante avec la library(data.table)
# prec <- fread("MFdataRRSorme.csv")
# prec <- as.data.frame(prec)

## C'est long à charger tout ça....il doit y avoir pas mal de données!
dim(prec)
# ...en effet!
head(prec)
## On a : le Numéro de la station, l'année, le mois et le jour...et les précipitations (RR)

# Dans le tableau, il manque pour certaines stations les données le 29 février
# Pour éviter d'avoir des "trous" et homogénéiser le jeu de données, on éliminer
# tous les 29 février (années bisextiles)
prec <- prec[ -which(prec$Day == 29 & prec$Month==2), ]


### Le facteur d'érosivité du modèle (R)USLE va être estimé à partir des cumuls de pluie annuels
# Or, ici, on a des données quotidiennes
# On va donc AGREGER les données
# par station et par an....
## Comment pourriez-vous faire autrement  pour calculer les cumuls annuels

precAn <- aggregate(prec$RR,
  by = list(NumPoste = prec$NumPoste, Year = prec$Year),
  FUN = function(x) sum(x, na.rm = TRUE)
)
head(precAn)
tail(precAn)

hist(precAn$x)

summary(precAn)
View(precAn)
## Il y a 1251 couples années/stations pour lesquels on a pas de données!
## Comptons les années manquantes par station
## Toutefois certains cumuls sont anormalement bas 

manq <- tapply(precAn$x, INDEX = list(precAn$NumPoste),
               FUN = function(x) sum(x<400))
length(manq)

# length(unique(precAn$NumPoste  ))
# Un petit histogramme pour visualiser tout cela
hist(manq)
# Voyons maintenant le nombre de stations qui ont des données  par année
nstationsAn <- tapply(precAn$x,
  INDEX = list(precAn$Year),
  FUN = function(x) sum(x >= 400)
)

nstationsAn["2015"]
# ajoutons les années en axes des abscisses
ans <- as.numeric(names(nstationsAn))
plot(x = ans, y = nstationsAn, type = "o")
grid()
# On a beaucoup moins de stations à partir de 2010!

## Identification des cumuls annuels anormalement bas
indr <- which(precAn$x < 400)

precAn <- precAn[-indr, ]
hist(precAn$x)
summary(precAn)

## Fusionnons maintenant les données avec les coordonnées des stations

## On va commencer par transformer notre tableau de cumul de précipitaions en mettant les cumuls annuels en colonne et les stations en ligne.
## POur cela, on utilise le package "reshape2"
library(reshape2)
## Pour plus d'aide pour manipuler ce package : https://seananderson.ca/2013/10/19/reshape.html
precAnRemanie <- dcast(precAn, NumPoste ~ Year, value.var = "x")
dim(precAnRemanie)
## Qu'est-ce que ça donne?
View(precAnRemanie)

## Ici, il y a un petit problème :
## les colonnes des années sont nommées avec des chiffres uniquement (ex= 1961, etc.)
## Il risque d'y avoir une confusion entre numéro de colonne et numéro de l'année
## R va "se demander" quand on fait référence à l'année 2000,
## s'il faut chercher la 2000è colonne du tableau, ou s'il s'agit de la colonne dénommée "2000"
## Pour éviter cette confusion on met un préfixe devant les chiffres de l'année

colnames(precAnRemanie)[-1] <- paste0("y", colnames(precAnRemanie)[-1]) # Ici, le [-1] permet de ne pas appliquer l'opération à la première colonne, appelée NumPoste

save(precAnRemanie,file="precAnRemanie.RData")

View(precAnRemanie) # Le nom des années en colonne à un petit "y" en préfixe maintenant


# On fusionne ces données avec les coorodnnées des stations, pour n'avoir qu'un seul fichier
# Récuparation des coordonnées en Lambert 93 (depuis la couche vectorielle "points")
coordsL93 <- coordinates(stations)
head(coordsL93)
# R nous a remis des noms des colonnes peu explicite...
# Mais comme on a reprojeté cette couche en Lambert 93, il faut renommer correctement
# Les colonnes!
colnames(coordsL93) <- c("X", "Y")
# Il manque le numéro des stations et l'altitude des postes...on les rajoute!
coordsL93 <- cbind(NumPoste = coords$NumStation, coordsL93, Alti = coords$alti)
head(coordsL93) # ...c'est mieux!

# Maintenant on fusionne les deux tableaux de données
pAn <- merge(x = coordsL93, y = precAnRemanie, by = "NumPoste")
View(pAn)

####################################################################################
####### ANALYSE STATISTIQUE -----
####################################################################################
#### Nous allons etudier ici une seule variable : les précipitations de l'année 2001
# On identifie la variable à analyser (colonne nommée "y2001")
v <- "y2001"
# On isole les coordonnées et l'année 2001
dat <- pAn[, c("NumPoste", "X", "Y", "Alti", v)]
dim(dat) # On a 87 stations
summary(dat) # Pour 5 stations, pas de cumul en 2000 (du fait de données manquantes)
# et on élimine les données manquantes
dat <- na.omit(dat)
summary(dat)
dim(dat) # Reste donc 82 stations
View(dat)

# Variable à spatialiser
hist(dat[, v], xlab = paste0("Cumul de precipitations en ", v, " (mm)"), main = "Histogramme")
# Altitude
summary(dat[, "Alti"])
hist(dat[, "Alti"], xlab = "Altitude [m]", main = "")

##################################################################################################
## trace carte avec mnt + stations + limite du bassin versant
               
dat_sf <- st_as_sf(dat, coords = c("X", "Y"), crs = "+init=epsg:2154")


ggplot(data = mnt75mdf) +
  geom_raster(aes(x = x, y = y, fill = `alti`)) +
  scale_fill_viridis_c() +
  geom_sf(data = BVSorme, color = "red", fill = NA) +
  geom_sf(data = dat_sf, aes(geometry = geometry, size = y2001))

#########################################################################################################
# Liens entre variable à interpoler (ici le cumul annuel de pluie) et les coordonées X, Y et l'altitude #
#########################################################################################################

# plot --> nuage  de point
# cor.test --> test de correlation
plot(dat[, "Alti"], dat[, v])
cor.test(dat[, "Alti"], dat[, v], use = "pairwise.complete.obs")
plot(dat[, "X"], dat[, v])
abline(lm(dat[, v] ~ dat[, "X"]))
cor.test(dat[, "X"], dat[, v], use = "pairwise.complete.obs")
plot(dat[, "Y"], dat[, v])
cor.test(dat[, "Y"], dat[, v], use = "pairwise.complete.obs")


# Correlations partielles
# install.packages("ppcor")
library(ppcor)
# Y a t il un lien entre la variable v et l'altitude, quand on retire "l'effet" de la longitude?
pcor.test(dat[, v], dat[, "Alti"], dat[, "X"])
# Y a t il un lien entre la variable v et l'altitude, quand on retire "l'effet" de la latitude?
pcor.test(dat[, v], dat[, "Alti"], dat[, "Y"])

######################################################################################
### CONCLUSIONS?
#####################################################################################

### Modèle de regression linéaire : ----
### peut-on prévoir la variable à interpoler à partir de l'altitude, de la latitude (Y) et de la longitude (X)
# Modèle linéaire multiple
# On créé une formule
mod1 <- lm(formula(paste0(v, " ~ Alti + X + Y")), data = dat)
mod <- lm(y2001 ~ Alti + X + Y, data = dat)
mod
summary(mod1)
summary(mod)

# Statistiques du modèle linéaire :

# Nuage de points entre valeurs observées et prédites
lims <- range(dat[, v], mod$fitted.values, na.rm = T)
plot(dat[, v], mod$fitted.values, xlab = "Valeurs observées [mm]", ylab = "Valeurs prédites [mm]", xlim = lims, ylim = lims, pch = 20, col = rgb(0, 0, 0, alpha = 0.3))
abline(a = 0, b = 1)

residus <- predict(mod) - dat[, v]

mean(residus) # Biais
hist(residus, n = 50) # Les résidus suivent-t-ils une loi normale?
summary(residus)
sd(residus) # ecart-type de résidus
sqrt(mean(residus^2)) # RMSE

############################################################################
#### Conclusions?
############################################################################


############################################################################
### Interpolation spatiale par regression linaire ----
### On estime la valeur de la variable pour chaque cellule (pixel)
### du MNT à 75 m
### Les coordonnées des points cibles sont donc le centre de chaque pixel

### Afin d'appliquer le modèle linéaire aux points cibles, il faut créer un data.frame avec les mêmes noms de variables que ceux présents dans le modèle (cf. data.frame appelé "pts.source" plus haut)
pts.cibles <- data.frame(
  Alti = getValues(mnt75m),
  X = coordinates(mnt75m)[, 1], Y = coordinates(mnt75m)[, 2]
)
head(pts.cibles) # Coordonnées des pixels du mnt75m


### L'interpolation est réalisée en prédisant le modèle au point cibles
# pred.val2 <- predict.lm(object =  mod, newdata = pts.cibles[1000000,])
pred.val <- coef(mod)["(Intercept)"] +
  coef(mod)["Alti"] * pts.cibles$Alti +
  coef(mod)["X"] * pts.cibles$X +
  coef(mod)["Y"] * pts.cibles$Y

summary(pred.val)

### On affecte les données interpolées de la variable au dataframe  qui contient les
### altitudes en créant une nouvelle colonne 'ppred'

mnt75mdf$ppred <- pred.val

# Carte des précipitations interpolées

ggplot(data = mnt75mdf) +
  geom_raster(aes(x = x, y = y, fill = `ppred`)) +
  scale_fill_viridis_c() +
  geom_sf(data = BVSorme, color = "red", fill = NA)

## On transforme le rasultats en une image i.e. raster
pred.raster <- mnt75m
pred.raster[] <- NA ### On efface toutes les données du raster

pred.raster[] <- mnt75mdf$ppred

clip.raster <- mask(pred.raster, mask = BVSorme)
clip.raster <- crop(clip.raster, extent(BVSorme))
plot(clip.raster, col = vCols(50))

### Enregistrement du raster produit au format GeoTiff ----
## Donner un nom au raster de sortie

# Le bassin versant de la Sorme ne représente qu'une toute petite superficie....
# réduisons le raster d'interpolation créé aux limites du bassin versant
# Pour cela, on découpe le raster à l'étendue du BV

pred.raster.BV <- crop(x = pred.raster, y = BVSorme)
plot(pred.raster.BV, col = vCols(50))
plot(st_geometry(BVSorme), add = TRUE)

## Mieux encore...on élimine tout ce qui sort du BV :
 pred.raster.BV <- mask(x = pred.raster.BV, mask = BVSorme)
 plot(pred.raster.BV, col = vCols(50))
 plot(st_geometry(BVSorme), add = TRUE)

## On enregistre le fichier

nom.raster <- paste0("RegLin_CumulPrec_", v, ".tif")
writeRaster(pred.raster.BV, filename = nom.raster, format = "GTiff", overwrite = T)
