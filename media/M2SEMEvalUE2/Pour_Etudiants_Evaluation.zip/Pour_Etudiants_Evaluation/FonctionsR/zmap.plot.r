#

zmap.plot <- function(x,y=NULL,z=NULL, breaks=NULL, n=5, break.type="pretty",
                        pch=21, col=NULL, bg=NULL,
                        cex=1, grow.fact=0.2,
                        leg = T, leg.bg="white", x.leg="topright", leg.title = NULL, ncol.leg=1,
                        cex.leg = par("cex"),
                        cols=NULL, alpha=1,
                        add=F, dig.lab=4,
                         ...)
{
  if(is.null(y))
  {
    z <- x[,3] ; y <- x[,2] ; x <- x[,1]
  }
  if(is.null(breaks))
    if(break.type == "pretty")
    {
      breaks <- pretty(z,n=n)
    } else {
      breaks <- seq(min(z),max(z), length.out=n+1)
    }
  vals <- cut(z, breaks, include.lowest=T, dig.lab=dig.lab)
  cexs <- cex + grow.fact*(1:length(levels(vals)))
  if(is.null(col))
  {
    col <- colorRampPalette(c("blue3","wheat","red3"))
    col <- col(length(levels(vals)))
  }
  if(is.function(col))   col <- col(length(levels(vals)))
  if(length(col) == 1)   col <- rep(col[1],length(vals))

  if(is.null(bg))
  {
    bg <- colorRampPalette(c("blue3","wheat","red3"))
    bg <- bg(length(levels(vals)))
  }
  cat(class(bg))
  if(is.function(bg))   bg <- bg(length(levels(vals)))
  if(length(bg) == 1)    bg <- rep(bg[1],length(vals))
  
  if(add==T)
  {
    points(x, y, pch=pch, cex=cexs[vals], col=col[vals], bg=bg[vals],
        ...)
  } else {
    plot(x, y, pch=pch, cex=cexs[vals], col=col[vals], bg=bg[vals],
        ...)
  }
  if(leg==T)
    legend(x=x.leg, legend=levels(vals), pt.cex=cexs, col=col, pch=pch, bg=leg.bg, pt.bg=bg, title=leg.title, cex= cex.leg, ncol = ncol.leg)
  cat("Classes : ", paste(levels(vals), collapse=" , "), "\n")
}


col2col <- function(cols=c("orange","red3","black"), n=100, alpha=1, spline=F)
{
  rgb.val <- col2rgb(cols)/255

  if(spline == F)
  {
    rgb.val <- apply(rgb.val,1,
                    function(x) approx(x=seq(1,n,length.out=length(cols)),
                               y = x, n)[["y"]])
  } else {
    rgb.val <- apply(rgb.val,1,
                    function(x) spline(x=seq(1,n,length.out=length(cols)),
                              y = x, n=n)[["y"]])
  }
  rgb.val[rgb.val > 1] <-1 ;   rgb.val[rgb.val < 0] <- 0
  cols <- rgb(rgb.val["red"], rgb.val["green"], rgb.val["blue"], alpha=alpha)
  return(cols)
}

